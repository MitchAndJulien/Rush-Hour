/**
 * Driver class that launches the game
 * @author julienzhu
 *
 */
public class Driver{
	
	/**
	 * Creates a new RushHourBoard
	 * @param args main method
	 */
	public static void main(String[] args) {
		RushHourBoard test = new RushHourBoard();
	}

}
